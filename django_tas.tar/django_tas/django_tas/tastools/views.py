from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.views.generic import (
        ListView, DetailView, CreateView, UpdateView
)
from .models import Script
from .forms import FindUsers
from django.contrib import messages
from django.contrib.auth.models import User
from django.urls import reverse


# Create your views here.
@login_required
def home(request):
    context = {
        'scripts': Script.objects.all()
    }
    return render(request, 'tastools/home.html', context)

class ScriptListView(LoginRequiredMixin,ListView):
    model = Script
    template_name = 'tastools/home.html' # <app>/<model>_<viewtype>.html
    context_object_name = 'scripts'
    ordering = ['date_created']

class ScriptDetailView(LoginRequiredMixin, DetailView):
    model = Script

class ScriptCreateView(LoginRequiredMixin, CreateView):
    model = Script
    fields = ['title', 'scriptname']

class ScriptUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):

    raise_exception = False
    permission_required = 'tastools.change_script'
    permission_denied_message = ""
    login_url = '/home/'
    redirect_field_name = 'next'

    model = Script
    fields = ['title', 'scriptname']


def about(request):
    return render(request, 'tastools/about.html', {'title': 'About'})

def userresult(request):
    return HttpResponse('<h1>Hello HttpResponse</h1>')

def findusers(request):
    if request.method == 'POST':
        form = FindUsers(request.POST)

        if form.is_valid():
            surname = form.cleaned_data.get('surname')
            user = User.objects.filter(last_name=surname).first()

            if user:
                user_name = user.username
                first_name = user.first_name
                last_name = user.last_name
                #messages.success(request, f'Surname ({ user_name, first_name, last_name }) has been found!')
            else:
                form = FindUsers()

                context = {
                    'form': form
                }

                messages.warning(request, 'User not found.')
                return render(request, 'tastools/find_users.html', context)

            context = {
                'user_name': user_name,
                'first_name': first_name,
                'last_name': last_name
            }
            return render(request, 'tastools/find_users_result.html', context)
    else:
        form = FindUsers()

    context = {
        'form': form
    }

    return render(request, 'tastools/find_users.html', context)
