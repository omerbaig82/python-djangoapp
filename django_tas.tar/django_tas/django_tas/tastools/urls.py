from django.urls import path
from .views import ScriptListView, ScriptDetailView, ScriptCreateView, ScriptUpdateView
from . import views

urlpatterns = [
            path('', ScriptListView.as_view(), name='tastools-home'), # <app>/<model>_<viewtype>.html
            path('about/', views.about, name='tastools-about'),
            path('scriptdetail/<int:pk>/', ScriptDetailView.as_view(), name='script-detail'),
            path('scriptdetail/new/', ScriptCreateView.as_view(), name='script-create'),
            path('scriptdetail/<int:pk>/update/', ScriptUpdateView.as_view(), name='script-update'),
            path('findusers/', views.findusers, name='tastools-findusers'),
            path('findusers/result', views.userresult, name='tastools-findusers-result'),
            ]
