from django.db import models
from django.utils import timezone
from django.urls import reverse

# Create your models here.
class Script(models.Model):
    title = models.CharField(max_length=100)
    scriptname = models.CharField(max_length=100)
    date_created = models.DateTimeField(default=timezone.now)

    def __repr__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('script-detail', kwargs={'pk': self.pk})

